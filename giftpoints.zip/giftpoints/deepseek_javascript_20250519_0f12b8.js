// ... (الكود السابق يبقى كما هو حتى دالة sendPurchaseEmail)

function sendPurchaseEmail() {
    const templateParams = {
        to_email: 'rifainabil20@gmail.com',
        from_name: 'تطبيق تجميع النقاط',
        subject: 'عملية شراء جديدة',
        message: 'تم إجراء عملية شراء 1000 نقطة في التطبيق. يرجى مراجعة النظام ومعالجة الطلب.',
        date: new Date().toLocaleString()
    };

    emailjs.send('service_n7hijxp', 'template_7t2q4o5', templateParams)
        .then(function(response) {
            console.log('الإرسال ناجح:', response);
            Swal.fire('تم الإرسال!', 'سيصلك تأكيد بالبريد الإلكتروني', 'success');
        }, function(error) {
            console.error('فشل الإرسال:', error);
            Swal.fire('خطأ!', 'تعذر إرسال التأكيد، يرجى المحاولة لاحقاً', 'error');
        });
}

// ... (بقية الكود يبقى كما هو)